function drawShape(){
    var canvas = document.getElementById('canvasBox');
    var ctx = canvas.getContext('2d');
    ctx.fillRect(20, 20, 100, 100);
}